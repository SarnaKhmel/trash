import "./App.css";
import UserList from "./coponents/UserList";
function App() {
  return (
    <div className="App">
      <UserList />
    </div>
  );
}

export default App;
