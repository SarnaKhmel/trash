import React from "react";

const UserList = () => {
  return <div>UserList</div>;
};

export default UserList;
